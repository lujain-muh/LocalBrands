//
//  LocalBrandsApp.swift
//  LocalBrands
//
//  Created by lujain mohammed on 04/11/1444 AH.
//

import SwiftUI

@main
struct LocalBrandsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
